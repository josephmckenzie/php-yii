<?php

return [
    'adminEmail' => 'joseph.mckenzie@minedminds.org',
];
