<?php

return [
    'DB_USER' => 'joe',
    'DB_PASSWORD' => 'password123',
	   'DB_HOST' => 'mysql:host=yii2basic.c9odwixmfpp7.us-east-1.rds.amazonaws.com;port=3306;dbname=yii2basic;charset=utf8'
];